
# ONCUP - Site Institucional

Este é o repositório do site institucional da ONCUP, o modelo de microcafeterias com identidade brasileira.

## 🚀 Como publicar

1. Faça upload deste repositório para sua conta GitHub
2. Acesse [vercel.com](https://vercel.com), conecte sua conta GitHub
3. Clique em “Add New Project” > Selecione `oncup-site`
4. Publique! Seu site estará disponível em algo como `https://oncup.vercel.app`

## 💡 Sobre a ONCUP

Mais que café. Uma experiência com alma. Inspirado no Brasil, criado para o mundo urbano.
